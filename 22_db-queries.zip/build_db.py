#MWE :: Evan Khosh, Robert Chen, Ashley, Maya
#SoftDev
#22_db-queries :: SQLITE3 BASICS
#Oct 2024
#time taken : 1 hr

import sqlite3   #enable control of an sqlite database
import csv       #facilitate CSV I/O
import random


DB_FILE="discobandit.db"

db = sqlite3.connect(DB_FILE) #open if file exists, otherwise create
c = db.cursor()               #facilitate db ops -- you will use cursor to trigger db events

#==========================================================

c.execute("CREATE TABLE IF NOT EXISTS students(name TEXT, age INTEGER, id INTEGER, UNIQUE(id))") #UNIQUE makes sure every value in the id column is unique

with open('students-beeg.csv', newline='') as studentscsv:
    reader = csv.DictReader(studentscsv)
    for row in reader:
        c.execute(f"INSERT OR IGNORE INTO students VALUES (\"{row['name']}\", {row['age']}, {row['id']})") #IGNORE is used when the UNIQUE parameter would be violated

c.execute("CREATE TABLE IF NOT EXISTS courses(code TEXT, mark INTEGER, id INTEGER)")

with open('courses-beeg.csv', newline='') as coursescsv:
    reader = csv.DictReader(coursescsv)
    for row in reader:
        c.execute(f"INSERT INTO courses (code, mark, id) SELECT \"{row['code']}\", {row['mark']}, {row['id']} WHERE NOT EXISTS (SELECT 1 FROM courses WHERE code = \"{row['code']}\" AND mark = {row['mark']} AND id = {row['id']})")
        #This only inserts the values if the row does not exist (we cannot use UNIQUE because we will have repeats of ids)
        #WHERE NOT EXISTS makes sure the stuff after does not exist
        #We try to select a row with the same values as the one we're adding, and if we can in triggers the WHERE NOT EXISTS statement

#Print Student Names
print("\nSTUDENTS:\n")
studentdata = c.execute("SELECT name, id FROM students;")
for row in studentdata:
    if row[0] not in studentnames:
        print(row[0] + " " + str(row[1]))

#Print Course Names
print("\nCOURSES:\n")
coursedata = c.execute("SELECT code FROM courses;")
coursenames = []
for row in coursedata:
    if row[0] not in coursenames:
        coursenames.append(row[0]) #We store the course names in a list first so we can filter out duplicates
for name in coursenames:
    print(name)
    
#Print Students Over 50
print("\nSTUDENTS OVER 50:\n")
studentdata = c.execute("SELECT * FROM students;")
studentnames = []
for row in studentdata:
    if row[1] > 50:
        print(row[0] + " " + str(row[2]))
    
#Print Random Student's Grades
print("\nRANDOM STUDENT'S GRADES:\n")
id = random.randint(0,3300)
name = c.execute(f"SELECT name FROM students WHERE id = {id};") #SELECT returns an SQL pointer so we can't plug this directly into our print statement
print(name.fetchone()[0] + " " + str(id))                       #We need this line using fetchone to grab the first row out of our selected values
gradesdata = c.execute(f"SELECT code, mark FROM courses WHERE id = {id};")
for row in gradesdata:
    print(f"Course: {row[0]} - Grade: {row[1]}")
    
#Print All SoftDev Students
print("\nALL SOFTDEV STUDENTS:\n")
idsdata = c.execute(f"SELECT id FROM courses WHERE code = \"softdev\";")
ids = []
for row in idsdata: #We need to store the idsdata in a list because SQL can only store one set of selected data at a time
    ids.append(row[0])
for row in ids:
    name = c.execute(f"SELECT name FROM students WHERE id = {row};") #When we run this execute, the id data we selected earlier is overwritten
    print(name.fetchone()[0] + " " + str(row))


#==========================================================

db.commit() #save changes
db.close()  #close database
